# carros_motos_pessoas > 2026-01-17 11:52am
https://universe.roboflow.com/ufc-trabalho/carros_motos_pessoas

Provided by a Roboflow user
License: CC BY 4.0

